import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
@Injectable()
export class UserInfoService
{
    private url:string="https://jsonplaceholder.typicode.com/users";

    constructor(private http:HttpClient)
    {

    }
    public getUserInfo():Observable<any[]>
    {
      return this.http.get<any[]>(this.url);
    }
    getData(startIndex, pageSize): Observable<any> {
        return this.http.get(this.url + '?page=' + startIndex + '&limit=' + pageSize)
            .map(this.extractData);
    }

    extractData(result: Response) {
        return result.json();
    }

}