import {Injectable} from "@angular/core";
import {MenuData} from "../models/menudata";
import {Menu} from "../models/menu";


@Injectable()
export class MenuService
{

    public getMenuItems():Menu[]
    {
        return MenuData;
    }

}