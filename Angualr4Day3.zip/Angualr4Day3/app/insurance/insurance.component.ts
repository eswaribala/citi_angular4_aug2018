import {Component} from "@angular/core";


@Component({

    templateUrl:'./app/insurance/insurance.component.html',
    styleUrls:['./app/insurance/insurance.component.css']
})

export class InsuranceComponent
{

}