import {Routes, RouterModule} from "@angular/router";
import {BankingComponent} from "./banking/banking.component";
import {HomeLoansComponent} from "./homeloans/homeloans.component";
import {NgModule} from "@angular/core";
import {CreditcardComponent} from "./creditcard/creditcard.component";
import {InsuranceComponent} from "./insurance/insurance.component";


const routes:Routes=[
    {
        path: 'Banking',
        component: BankingComponent,
        outlet: 'left'
    },

    {
        path: 'Home Loans',
        component: HomeLoansComponent,
        outlet: 'right'
    },
    {
        path: 'Credit Cards',
        component: CreditcardComponent

    },

    {
        path: 'Insurance',
        component:InsuranceComponent

    }


]

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})

export class AppRoutingModule
{

}