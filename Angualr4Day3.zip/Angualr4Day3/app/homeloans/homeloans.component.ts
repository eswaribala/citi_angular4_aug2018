import {Component} from "@angular/core";


@Component({

    templateUrl:'./app/homeloans/homeloans.component.html',
    styleUrls:['./app/homeloans/homeloans.component.css']
})

export class HomeLoansComponent
{

}