import {Component, OnInit} from "@angular/core";
import {UserInfoService} from "../services/userinfoservice";
import {DataSource} from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import {MatPaginator} from '@angular/material';
import 'rxjs/add/operator/map';
import {Subscriber} from "rxjs/Subscriber";

@Component({

    templateUrl:'./app/banking/banking.component.html',
    styleUrls:['./app/banking/banking.component.css']
})

export class BankingComponent implements OnInit
{
    private userData:any;
    private dataSource;
    private test:string="L";
    private filterChar:string='L';
    displayedColumns = ['name', 'phone'];
    // Pagination
    length:number=0;
    total_items:number;
    pageIndex:number = 1;
    pageSize:number = 5;
    pageSizeOptions:number[] = [5, 10, 25, 50, 100];
    data:any;
    constructor(private userInfoService:UserInfoService)
    {
          // this.dataSource=new UserDataSource(this.userInfoService);
    }

    readChange(data)
    {
        this.filterChar=data;
console.log(data);

    }


        ngOnInit()
        {
            //this.userData=this.userInfoService.getUserInfo();
             //console.log(this.userData);
            this.userInfoService.getUserInfo().subscribe(response=>{
               this.userData=response;
                //console.log(response);
                this.total_items=this.userData.length;
            })
            this.loadData(this.pageIndex);

        }
    loadData(target) {
        console.log(target);
        this.data = this.userInfoService.getUserInfo().map(x => x.slice(this.pageIndex,this.pageSize));

        this.data.subscribe(data => {
            console.log(data.length);
            this.total_items=data.length;
            this.setPagination( this.total_items, data['page'], data['page_size']);

            this.dataSource = new UserDataSource(data);
        });
    }
    setPagination(length, startIndex, pageSize) {
        this.length = length;
        this.pageIndex = startIndex;
        this.pageSize = pageSize;
    }

    onPaginateChange(event) {
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;
        this.loadData(this.pageIndex );
    }
}

export class UserDataSource extends DataSource<any> {
    constructor(private dataObj:any) {
        super();
    }
    connect(): Observable<any> {
        return Observable.create((observer: Subscriber<any>) => {
            observer.next(this.dataObj);
            observer.complete();
        });


    }
    disconnect() {}
}

