import { NgModule } from "../node_modules/@angular/core";
import { AppComponent } from "./app.component";
import { BrowserModule } from
 "../node_modules/@angular/platform-browser";
 import {CommonModule} from '../node_modules/@angular/common'
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./services/menuservice";
import {

    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule, MatFormField, MatFormFieldModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
} from '@angular/material';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {AppRoutingModule} from "./app.routingmodule";
import {BankingComponent} from "./banking/banking.component";
import {HomeLoansComponent} from "./homeloans/homeloans.component";
import {CreditcardComponent} from "./creditcard/creditcard.component";
import {InsuranceComponent} from "./insurance/insurance.component";
import {UserInfoService} from "./services/userinfoservice";
import {HttpClientModule} from "@angular/common/http";
import {UserNamePipe} from "./filters/filters.component";
import { FormsModule } from '@angular/forms';
@NgModule({
    imports:[BrowserModule,CommonModule,MatButtonModule,
       MatInputModule,MatFormFieldModule, BrowserAnimationsModule,AppRoutingModule,FormsModule,HttpClientModule,MatTableModule, MatPaginatorModule],
    declarations:[AppComponent,MenuComponent,BankingComponent,HomeLoansComponent,CreditcardComponent,InsuranceComponent,UserNamePipe],
    providers:[MenuService,UserInfoService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}