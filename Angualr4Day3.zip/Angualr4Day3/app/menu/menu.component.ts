import {Component, OnInit} from "@angular/core";
import {MenuService} from "../services/menuservice";
@Component({
    selector:"citi-menu",
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']
})
export class MenuComponent implements OnInit
{
    private citiMenu:any;

    constructor(public menuServiceObj:MenuService)
    {

    }

    ngOnInit()
    {
        this.citiMenu=this.menuServiceObj.getMenuItems();
    }

}