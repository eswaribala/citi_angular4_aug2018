import {Component} from '@angular/core'
@Component({
    selector:'citi-home',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']

})

export class AppComponent
{

    private logo:string;
    private banner:string;

    constructor()
    {
        this.logo='./app/images/citibank.jpg';
        this.banner='./app/images/banner.jpg';
    }

}