import {Component} from "@angular/core";


@Component({

    templateUrl:'./app/creditcard/creditcard.component.html',
    styleUrls:['./app/creditcard/creditcard.component.css']
})

export class CreditcardComponent
{

}