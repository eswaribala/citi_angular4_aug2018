import {Menu} from "./menu";


export var MenuData:Menu[]=[new Menu(1,"Home"),
    new Menu(2,"Banking"),
    new Menu(3,"Credit Cards"),
    new Menu(4,"Home Loans"),
    new Menu(5,"Insurance"),
    new Menu(6,"Wealth Management"),
    new Menu(7,"Services"),
    new Menu(8,"Special Offers"),
   // new Menu(9,"NRI Management"),

]