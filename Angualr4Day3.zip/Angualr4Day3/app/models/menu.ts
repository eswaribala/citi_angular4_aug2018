export class Menu
{
    private  _menuId:number;
    private  _menuName:string;

    constructor(id:number,name:string)
    {
        this._menuId=id;
        this._menuName=name;
    }
    get MenuId():number
    {
        return this._menuId;
    }
    set MenuId(value:number)
    {
        this._menuId=value;
    }
    get MenuName():string
    {
        return this._menuName;
    }
    set MenuName(value:string)
    {
        this._menuName=value;
    }
    
}