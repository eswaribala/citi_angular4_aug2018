import { NgModule } from "../node_modules/@angular/core";
import { AppComponent } from "./app.component";
import { BrowserModule } from
 "../node_modules/@angular/platform-browser";
 import {CommonModule} from '../node_modules/@angular/common'

@NgModule({
    imports:[BrowserModule,CommonModule],
    declarations:[AppComponent],
    bootstrap:[AppComponent]
})
export class AppModule
{

}